<?php
$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "edu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student-id'];
    $student_password = $_POST['student-password'];

    // Prepare the SQL statement
    $sql = "SELECT * FROM students WHERE student_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        
        // Verify the password
        if (password_verify($student_password, $student['password'])) {
            // Successful login
            session_start();
            $_SESSION['student_id'] = $student['id']; // Store student ID in session
            header("Location: dashboard.stud.html"); // Redirect to the student dashboard
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "Student ID not found.";
    }
}

$conn->close();
?>

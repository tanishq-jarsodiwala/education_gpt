<?php
$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "edu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $admin_username = $_POST['admin-username'];
    $admin_password = $_POST['admin-password'];

    // Prepare the SQL statement
    $sql = "SELECT * FROM admins WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $admin_username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        
        // Verify the password
        if (password_verify($admin_password, $admin['password'])) {
            // Successful login
            session_start();
            $_SESSION['admin_id'] = $admin['id']; // Store admin ID in session
            header("Location: dashboard.admin.html"); // Redirect to the dashboard
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "Admin username not found.";
    }
}

$conn->close();
?>

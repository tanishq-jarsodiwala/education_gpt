<?php
$servername = "localhost:3307"; // Make sure this is the correct port for your MySQL server
$username = "root";
$password = ""; // Leave this empty if you have no password for root
$dbname = "edu"; // Change from 'edu' to 'ed'

// Create connection
$conn = new mysqli('localhost:3307', 'root', '', 'edu');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student-id'];
    $name = $_POST['student-name'];
    $email = $_POST['student-email'];
    $institute_code = $_POST['institute-code'];
    $password = password_hash($_POST['student-password'], PASSWORD_DEFAULT);

    // Check if email already exists
    $check_sql = "SELECT * FROM students WHERE email = '$email'";
    $result = $conn->query($check_sql);

    if ($result->num_rows > 0) {
        echo "Error: Email already exists. Please use a different email address.";
    } else {
        // Insert the new student
        $sql = "INSERT INTO students (student_id, name, email, institute_code, password) 
                VALUES ('$student_id', '$name', '$email', '$institute_code', '$password')";

        if ($conn->query($sql) === TRUE) {
            echo "New student registered successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>

function validateLogin(event) {
    event.preventDefault(); // Prevent the form from submitting
  
    // Sample credentials
    const studentUsername = "student";
    const studentPassword = "student123";
    const adminUsername = "admin";
    const adminPassword = "admin123";
  
    // Get entered credentials and role
    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
  
    // Validate credentials based on selected role
    if (role === "student" && username === studentUsername && password === studentPassword) {
      // Redirect to student dashboard if student credentials are valid
      window.location.href = "dashboard.stud.html";
    } else if (role === "admin" && username === adminUsername && password === adminPassword) {
      // Redirect to admin dashboard if admin credentials are valid
      window.location.href = "dashboard.admin.html";
    } else {
      // Display error message if credentials are invalid
      document.getElementById("error-msg").innerText = "Invalid username or password for " + role + ".";
    }
  }
  
<?php
$servername = "localhost:3307";
$username = "root";
$password = "";
$dbname = "edu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['admin-name'];
    $username = $_POST['admin-username'];
    $password = password_hash($_POST['admin-password'], PASSWORD_DEFAULT);
    $institute_name = $_POST['institute-name'];
    $institute_address = $_POST['institute-address'];
    $institute_code = $_POST['institute-code'];
    $subscription_plan = $_POST['subscription'];

    // Check if username already exists
    $check_sql = "SELECT * FROM admins WHERE username = '$username'";
    $result = $conn->query($check_sql);

    if ($result->num_rows > 0) {
        echo "Error: Username already exists. Please choose a different username.";
    } else {
        // Insert the new admin
        $sql = "INSERT INTO admins (name, username, password, institute_name, institute_address, institute_code, subscription_plan) 
                VALUES ('$name', '$username', '$password', '$institute_name', '$institute_address', '$institute_code', '$subscription_plan')";

        if ($conn->query($sql) === TRUE) {
            echo "New admin registered successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>
